import React from "react";

export default function ExplanationPanel({ explanation }) {
  return (
    <div className="mt-4 p-4 border border-green-600 bg-green-100 dark:bg-green-900 dark:border-green-400 rounded">
      <h2 className="font-semibold mb-2">Explanation:</h2>
      <p>{explanation}</p>
    </div>
  );
}
